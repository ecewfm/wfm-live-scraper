// content_roster.js — Wyze Dashboard Scraper (WFM Live)
// Runs on the WFM Agent Status page (https://wyzelabs.zendesk.com/wfm/v2/agent-status).
// Scrapes the ECE team's agent roster and sends it to background.js, which
// writes straight into WFM Live's Supabase `wyze_agents` table — the same
// table wfm-live-scraper's scrapers/wyze/index.js writes to.
//
// DOM-scraping logic (findEceAgentLis / parseAgentLi / selectByTeamIfNeeded)
// is a direct port of scrapers/wyze/index.js's scrapeEceRoster() and
// selectByTeamIfNeeded() — that code runs inside Playwright's page.evaluate(),
// this runs directly in the page as a content script, so the logic is
// unchanged, just no longer wrapped in an evaluate() call.

(function () {
  'use strict';

  const TARGET_GROUP = 'ECE';

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ── "By team" dropdown — Ant Design only opens it on mousedown; a plain
  // .click() already fires mousedown/mouseup/click, so this is enough. ──────
  async function selectByTeamIfNeeded() {
    const current = document.querySelector('.ant-select-selection-item');
    if (current && (current.getAttribute('title') === 'By team')) return;

    const trigger = document.querySelector('.ant-select-selector');
    if (!trigger) return;
    trigger.click();

    const deadline = Date.now() + 5000;
    let byTeamOption = null;
    while (Date.now() < deadline) {
      byTeamOption = document.querySelector(
        '.ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option[title="By team"]'
      );
      if (byTeamOption) break;
      await sleep(150);
    }
    if (byTeamOption) byTeamOption.click();
  }

  async function waitForAgentListDom(maxMs = 30000) {
    const deadline = Date.now() + maxMs;
    while (Date.now() < deadline) {
      const vList = document.querySelector('.virtual-list');
      if (vList && vList.querySelectorAll('li.sc-dkYRCH').length > 0) return true;
      await sleep(300);
    }
    return false;
  }

  function findEceAgentLis(vList) {
    const allLis = Array.from(vList.querySelectorAll('li.sc-dkYRCH'));
    let eceIdx = -1;
    allLis.forEach((li, i) => {
      const h6 = li.querySelector('h6');
      if (h6 && h6.innerText.trim() === TARGET_GROUP) eceIdx = i;
    });
    if (eceIdx === -1) return [];
    const parentUl = allLis[eceIdx].parentElement;
    if (!parentUl) return [];
    const siblings = Array.from(parentUl.children);
    const eceUlIdx = siblings.indexOf(allLis[eceIdx]);
    const agentLis = [];
    for (let i = eceUlIdx + 1; i < siblings.length; i++) {
      const li = siblings[i];
      const h6 = li.querySelector('h6');
      const lines = li.innerText.trim().split('\n').map(s => s.trim()).filter(Boolean);
      if (h6 && lines.length <= 2) break; // next team's header row — stop
      agentLis.push(li);
    }
    return agentLis;
  }

  function parseAgentLi(li) {
    const nameEl = li.querySelector('h6');
    const name = nameEl ? nameEl.innerText.trim() : '';
    const perf = li.querySelector('[data-testid="AgentPerformanceContent"]');
    const getCol = id => {
      if (!perf) return '';
      const el = perf.querySelector(`[data-testid="${id}"]`);
      return el ? el.innerText.trim().replace(/\n/g, ' ').trim() : '';
    };
    const badgeEl = li.querySelector('[data-testid="AgentDetailsColoredTask"]');
    const activity = badgeEl ? badgeEl.innerText.trim() : getCol('ColumnWorkstream');
    return {
      name, activity,
      ticketNumber: getCol('ColumnTicketId'),
      activityDuration: getCol('ColumnActivityDuration'),
      adherenceCurrent: getCol('ColumnAdherenceCurrent'),
      adherenceDuration: getCol('ColumnAdherenceDuration'),
      status: getCol('ColumnTalkActivity'),
      statusDuration: getCol('ColumnTalkActivityDuration'),
    };
  }

  // Virtual list only renders visible rows — scroll it through its full
  // range and dedupe by agent name, same as the Node scraper does.
  async function scrapeEceRoster() {
    const vList = document.querySelector('.virtual-list');
    if (!vList) return [];

    const agentMap = new Map();
    const stepSize = Math.max(vList.clientHeight - 60, 60);
    const savedPos = vList.scrollTop;
    const addAgents = () => {
      findEceAgentLis(vList).forEach(li => {
        const agent = parseAgentLi(li);
        if (agent.name) agentMap.set(agent.name, agent);
      });
    };
    vList.scrollTop = 0; await sleep(200); addAgents();
    let lastTop = -1;
    while (true) {
      const atBottom = vList.scrollTop >= vList.scrollHeight - vList.clientHeight - 5;
      if (atBottom || vList.scrollTop === lastTop) break;
      lastTop = vList.scrollTop;
      vList.scrollTop += stepSize;
      await sleep(200); addAgents();
    }
    addAgents();
    vList.scrollTop = savedPos;
    return Array.from(agentMap.values());
  }

  function safeSend(msg) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage(msg, res => {
          if (chrome.runtime.lastError) resolve(null);
          else resolve(res);
        });
      } catch (e) { resolve(null); }
    });
  }

  async function onSnap() {
    await selectByTeamIfNeeded().catch(() => {});
    const agents = await scrapeEceRoster();
    if (agents.length === 0) {
      return { ok: false, error: 'No ECE agents found — is the roster fully loaded and "By team" selected?' };
    }
    const res = await safeSend({ type: 'WYZE_WRITE_AGENTS', agents });
    if (!res?.ok) return { ok: false, error: res?.error || 'background write failed' };
    return {
      ok: true,
      summary: `Synced ${agents.length} ECE agent(s) to wyze_agents`,
      previewItems: agents.map(a => ({ name: a.name, detail: `${a.status || '-'} ${a.statusDuration || ''}`.trim() })),
    };
  }

  async function init() {
    const ready = await waitForAgentListDom();
    if (!ready) {
      console.warn('[Wyze Roster] Agent list never appeared — is the WFM Agent Status page fully loaded?');
    }
    await selectByTeamIfNeeded().catch(() => {});

    window.WyzeOverlay.create({
      title: 'Wyze Agent Roster Scraper',
      writesTo: 'WFM Live Supabase (wyze_agents)',
      storageKeyPrefix: 'wyze_roster',
      defaultInterval: 30,
      onSnap,
    });
  }

  setTimeout(init, 1500);
})();
